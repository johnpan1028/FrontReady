import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { MainLayout } from './layouts/MainLayout';
import { DashboardPage } from './pages/DashboardPage';
import { PlaceholderPage } from './pages/PlaceholderPage';
import { BuilderPage } from './pages/BuilderPage';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainLayout />}>
          <Route index element={<DashboardPage />} />
          <Route path="org" element={<PlaceholderPage title="组织管理 (Organization Management)" />} />
          <Route path="talent" element={<PlaceholderPage title="人才管理 (Talent Management)" />} />
          <Route path="productivity" element={<PlaceholderPage title="产能分析 (Productivity Analysis)" />} />
          <Route path="builder" element={<BuilderPage />} />
          <Route path="settings" element={<PlaceholderPage title="系统设置 (System Settings)" />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
