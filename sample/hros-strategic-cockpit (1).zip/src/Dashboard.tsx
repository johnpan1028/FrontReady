import { useState, useEffect } from 'react';
import { ResponsiveGridLayout } from 'react-grid-layout';
import { useContainerWidth } from './hooks/useContainerWidth';
import { Widget } from './components/Widget';
import { OrgChart } from './widgets/OrgChart';
import { TalentMatrix } from './widgets/TalentMatrix';
import { ProductivityTrend } from './widgets/ProductivityTrend';
import { TalentGrid } from './widgets/TalentGrid';
import { StatCards } from './widgets/StatCards';

const initialLayouts = {
  lg: [
    { i: 'stats', x: 0, y: 0, w: 12, h: 3, static: true },
    { i: 'org', x: 0, y: 3, w: 4, h: 9 },
    { i: 'talent', x: 4, y: 3, w: 4, h: 9 },
    { i: 'prod', x: 8, y: 3, w: 4, h: 9 },
    { i: 'grid', x: 0, y: 12, w: 12, h: 10 }
  ]
};

export function Dashboard() {
  const [layouts, setLayouts] = useState(initialLayouts);
  const { width, containerRef, mounted } = useContainerWidth();

  if (!mounted) {
    return <div ref={containerRef} className="h-full w-full p-4" />;
  }

  return (
    <div ref={containerRef} className="h-full w-full overflow-y-scroll overflow-x-hidden p-4">
      <ResponsiveGridLayout
        className="layout"
        layouts={layouts}
        width={width}
        breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
        cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
        rowHeight={30}
        dragConfig={{ handle: '.drag-handle' }}
        onLayoutChange={(layout: any, layouts: any) => setLayouts(layouts)}
        margin={[16, 16]}
      >
        <div key="stats" className="!bg-transparent !border-none !shadow-none">
          <StatCards />
        </div>
        <div key="org">
          <Widget title="组织架构分布 (Org Distribution)"><OrgChart /></Widget>
        </div>
        <div key="talent">
          <Widget title="人才九宫格 (Talent Matrix)"><TalentMatrix /></Widget>
        </div>
        <div key="prod">
          <Widget title="人效趋势 (Productivity Trend)"><ProductivityTrend /></Widget>
        </div>
        <div key="grid">
          <Widget title="核心人才库 (Core Talent Pool)"><TalentGrid /></Widget>
        </div>
      </ResponsiveGridLayout>
    </div>
  );
}
