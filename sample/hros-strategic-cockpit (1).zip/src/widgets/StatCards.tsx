import { Users, TrendingUp, DollarSign, Activity } from 'lucide-react';

const stats = [
  { label: '总编制 (Total HC)', value: '1,248', change: '+12', trend: 'up', icon: Users },
  { label: '核心流失率 (Core Turnover)', value: '2.4%', change: '-0.5%', trend: 'down', icon: Activity },
  { label: '人均产能 (Rev/Emp)', value: '¥1.8M', change: '+15%', trend: 'up', icon: TrendingUp },
  { label: '人力资本ROI (HC ROI)', value: '3.2x', change: '+0.4x', trend: 'up', icon: DollarSign },
];

export function StatCards() {
  return (
    <div className="grid grid-cols-4 gap-4 h-full">
      {stats.map((stat, idx) => {
        const isUp = stat.trend === 'up';
        const colorClass = isUp ? 'text-hr-success' : 'text-hr-danger';
        const bgClass = isUp ? 'bg-hr-success/10' : 'bg-hr-danger/10';

        return (
          <div key={idx} className="bg-hr-panel border border-hr-border rounded-xl p-5 flex flex-col justify-between shadow-sm">
            <div className="flex items-center justify-between text-hr-muted">
              <span className="text-xs font-medium uppercase tracking-wide">{stat.label}</span>
              <stat.icon size={18} />
            </div>
            <div className="flex items-end justify-between mt-4">
              <span className="text-3xl font-bold text-hr-text">{stat.value}</span>
              <span className={`text-xs font-medium px-2 py-1 rounded-md ${colorClass} ${bgClass}`}>
                {stat.change}
              </span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
