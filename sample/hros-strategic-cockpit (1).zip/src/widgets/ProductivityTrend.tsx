import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const data = [
  { month: 'Jan', revenue: 4000, cost: 2400 },
  { month: 'Feb', revenue: 3000, cost: 1398 },
  { month: 'Mar', revenue: 2000, cost: 9800 },
  { month: 'Apr', revenue: 2780, cost: 3908 },
  { month: 'May', revenue: 1890, cost: 4800 },
  { month: 'Jun', revenue: 2390, cost: 3800 },
  { month: 'Jul', revenue: 3490, cost: 4300 },
];

export function ProductivityTrend() {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
        <defs>
          <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#6B8E6B" stopOpacity={0.3}/>
            <stop offset="95%" stopColor="#6B8E6B" stopOpacity={0}/>
          </linearGradient>
          <linearGradient id="colorCost" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#C85A5A" stopOpacity={0.3}/>
            <stop offset="95%" stopColor="#C85A5A" stopOpacity={0}/>
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#E2DCD0" vertical={false} />
        <XAxis dataKey="month" stroke="#8C857B" tick={{ fill: '#8C857B', fontSize: 10 }} axisLine={false} tickLine={false} />
        <YAxis stroke="#8C857B" tick={{ fill: '#8C857B', fontSize: 10 }} axisLine={false} tickLine={false} />
        <Tooltip 
          contentStyle={{ backgroundColor: '#F8F6F0', borderColor: '#E2DCD0', color: '#3E3832', fontSize: '12px', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}
          itemStyle={{ color: '#3E3832' }}
        />
        <Area type="monotone" dataKey="revenue" stroke="#6B8E6B" strokeWidth={2} fillOpacity={1} fill="url(#colorRev)" />
        <Area type="monotone" dataKey="cost" stroke="#C85A5A" strokeWidth={2} fillOpacity={1} fill="url(#colorCost)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}
