import { useMemo } from 'react';
import { AgGridReact } from 'ag-grid-react';
import { ColDef, ModuleRegistry, AllCommunityModule } from 'ag-grid-community';

ModuleRegistry.registerModules([AllCommunityModule]);

export function TalentGrid() {
  const rowData = useMemo(() => [
    { id: 'EMP001', name: 'Alice Chen', role: 'Senior Engineer', dept: 'R&D', perf: 'A', risk: 'Low', salary: '¥450k' },
    { id: 'EMP002', name: 'Bob Smith', role: 'Sales Director', dept: 'Sales', perf: 'B+', risk: 'High', salary: '¥600k' },
    { id: 'EMP003', name: 'Charlie Davis', role: 'Ops Manager', dept: 'Ops', perf: 'A-', risk: 'Medium', salary: '¥350k' },
    { id: 'EMP004', name: 'Diana Wang', role: 'Product Lead', dept: 'R&D', perf: 'A+', risk: 'Low', salary: '¥550k' },
    { id: 'EMP005', name: 'Evan Liu', role: 'HRBP', dept: 'Admin', perf: 'B', risk: 'Low', salary: '¥280k' },
    { id: 'EMP006', name: 'Fiona Gallagher', role: 'Marketing Head', dept: 'Sales', perf: 'A', risk: 'Medium', salary: '¥480k' },
  ], []);

  const columnDefs = useMemo<ColDef[]>(() => [
    { field: 'id', headerName: 'ID', width: 100 },
    { field: 'name', headerName: '姓名 (Name)', flex: 1 },
    { field: 'role', headerName: '岗位 (Role)', flex: 1 },
    { field: 'dept', headerName: '部门 (Dept)', width: 120 },
    { 
      field: 'perf', 
      headerName: '绩效 (Perf)', 
      width: 100,
      cellStyle: params => {
        if (params.value.includes('A')) return { color: '#6B8E6B', fontWeight: 'bold' };
        return { color: '#3E3832' };
      }
    },
    { 
      field: 'risk', 
      headerName: '流失风险 (Risk)', 
      width: 140,
      cellStyle: params => {
        if (params.value === 'High') return { color: '#C85A5A', fontWeight: 'bold' };
        if (params.value === 'Medium') return { color: '#D9A05B' };
        return { color: '#6B8E6B' };
      }
    },
    { field: 'salary', headerName: '薪酬 (Comp)', width: 120 },
  ], []);

  const defaultColDef = useMemo(() => ({
    sortable: true,
    filter: true,
    resizable: true,
  }), []);

  return (
    <div className="ag-theme-quartz w-full h-full">
      <AgGridReact
        rowData={rowData}
        columnDefs={columnDefs}
        defaultColDef={defaultColDef}
        rowHeight={40}
        headerHeight={40}
        animateRows={true}
      />
    </div>
  );
}
