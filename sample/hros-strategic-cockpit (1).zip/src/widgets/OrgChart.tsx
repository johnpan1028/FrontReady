import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

const data = [
  { name: '研发 (R&D)', value: 400 },
  { name: '销售 (Sales)', value: 300 },
  { name: '运营 (Ops)', value: 300 },
  { name: '职能 (Admin)', value: 200 },
];

const COLORS = ['#D47253', '#6B8E6B', '#D9A05B', '#C85A5A'];

export function OrgChart() {
  return (
    <div className="w-full h-full flex flex-col">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="45%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
            stroke="none"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip 
            contentStyle={{ backgroundColor: '#F8F6F0', borderColor: '#E2DCD0', color: '#3E3832', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}
            itemStyle={{ color: '#3E3832' }}
          />
          <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '12px', color: '#8C857B' }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
