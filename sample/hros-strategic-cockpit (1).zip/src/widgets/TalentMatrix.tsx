import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';

const data = [
  { name: 'Alice', performance: 90, potential: 85, dept: 'R&D' },
  { name: 'Bob', performance: 60, potential: 95, dept: 'Sales' },
  { name: 'Charlie', performance: 80, potential: 60, dept: 'Ops' },
  { name: 'David', performance: 40, potential: 40, dept: 'Admin' },
  { name: 'Eve', performance: 95, potential: 90, dept: 'R&D' },
  { name: 'Frank', performance: 70, potential: 75, dept: 'Sales' },
  { name: 'Grace', performance: 85, potential: 80, dept: 'R&D' },
  { name: 'Heidi', performance: 50, potential: 65, dept: 'Ops' },
];

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-hr-panel border border-hr-border p-3 rounded-lg text-xs shadow-xl">
        <p className="font-bold text-hr-text mb-1">{data.name} ({data.dept})</p>
        <p className="text-hr-success">绩效 (Perf): {data.performance}</p>
        <p className="text-hr-primary">潜力 (Pot): {data.potential}</p>
      </div>
    );
  }
  return null;
};

export function TalentMatrix() {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#E2DCD0" />
        <XAxis type="number" dataKey="performance" name="Performance" domain={[0, 100]} stroke="#8C857B" tick={{ fill: '#8C857B', fontSize: 10 }} />
        <YAxis type="number" dataKey="potential" name="Potential" domain={[0, 100]} stroke="#8C857B" tick={{ fill: '#8C857B', fontSize: 10 }} />
        <Tooltip content={<CustomTooltip />} cursor={{ strokeDasharray: '3 3' }} />
        <ReferenceLine x={50} stroke="#8C857B" strokeOpacity={0.5} />
        <ReferenceLine y={50} stroke="#8C857B" strokeOpacity={0.5} />
        <Scatter name="Talents" data={data} fill="#D47253" />
      </ScatterChart>
    </ResponsiveContainer>
  );
}
