import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { BarChart2, Maximize2, Minimize2, Lock, Unlock, Eye, EyeOff } from 'lucide-react';
import { useState } from 'react';
import { cn } from '../utils/cn';

// We use a getter function to avoid circular dependencies
// The actual NestedCanvas component will be injected or imported dynamically
let NestedCanvasComponent: React.FC<{ id: string }> | null = null;

export const setNestedCanvasComponent = (Component: React.FC<{ id: string }>) => {
  NestedCanvasComponent = Component;
};

export const WidgetRegistry: Record<string, React.FC<any>> = {
  heading: ({ text }) => (
    <h2 className="text-xl font-bold text-hr-text h-full flex items-center w-full overflow-hidden">{text}</h2>
  ),
  text: ({ text }) => (
    <p className="text-sm text-hr-muted h-full w-full overflow-hidden">{text}</p>
  ),
  button: ({ text, variant }) => (
    <Button variant={variant} className="w-full h-full">{text}</Button>
  ),
  stat: ({ title, value }) => (
    <Card className="p-4 h-full flex flex-col justify-center w-full">
      <div className="text-sm text-hr-muted truncate">{title}</div>
      <div className="text-2xl font-bold text-hr-text truncate">{value}</div>
    </Card>
  ),
  chart: () => (
    <Card className="p-4 h-full flex flex-col items-center justify-center bg-hr-border/10 text-hr-muted w-full border-dashed">
      <BarChart2 size={32} className="opacity-50 mb-2" />
      <span className="text-xs">Chart Placeholder</span>
    </Card>
  ),
  panel: ({ id, title, showHeader, collapsed }) => {
    const [isCollapsed, setIsCollapsed] = useState(collapsed);
    const [isLocked, setIsLocked] = useState(false);
    const [isHidden, setIsHidden] = useState(false);

    if (isHidden) {
      return (
        <Card className="w-full h-full flex items-center justify-center bg-hr-border/20 border-dashed">
          <button onClick={() => setIsHidden(false)} className="text-hr-muted hover:text-hr-text flex items-center gap-2 text-sm">
            <EyeOff size={16} /> Hidden Panel
          </button>
        </Card>
      );
    }

    return (
      <Card className={cn("w-full h-full flex flex-col overflow-hidden", isLocked && "opacity-80 pointer-events-none")}>
        {showHeader && (
          <div className="flex items-center justify-between px-4 py-2 border-b border-hr-border bg-hr-panel/50">
            <h3 className="font-medium text-sm text-hr-text truncate">{title}</h3>
            <div className="flex items-center gap-1 pointer-events-auto">
              <button onClick={() => setIsLocked(!isLocked)} className="p-1 text-hr-muted hover:text-hr-text rounded hover:bg-hr-border/50">
                {isLocked ? <Lock size={14} /> : <Unlock size={14} />}
              </button>
              <button onClick={() => setIsHidden(true)} className="p-1 text-hr-muted hover:text-hr-text rounded hover:bg-hr-border/50">
                <Eye size={14} />
              </button>
              <button onClick={() => setIsCollapsed(!isCollapsed)} className="p-1 text-hr-muted hover:text-hr-text rounded hover:bg-hr-border/50">
                {isCollapsed ? <Maximize2 size={14} /> : <Minimize2 size={14} />}
              </button>
            </div>
          </div>
        )}
        <div className={cn("flex-1 overflow-hidden", isCollapsed && "hidden")}>
          {NestedCanvasComponent && <NestedCanvasComponent id={id} />}
        </div>
      </Card>
    );
  },
  canvas: ({ id }) => (
    <div className="w-full h-full border border-dashed border-hr-border/50 rounded-lg bg-hr-panel/30 overflow-hidden relative group/canvas-widget">
      <div className="absolute top-1 left-1/2 -translate-x-1/2 w-8 h-1.5 bg-hr-border rounded-full opacity-0 group-hover/canvas-widget:opacity-100 transition-opacity cursor-grab z-10" />
      <div className="w-full h-full pt-3">
        {NestedCanvasComponent && <NestedCanvasComponent id={id} />}
      </div>
    </div>
  )
};
