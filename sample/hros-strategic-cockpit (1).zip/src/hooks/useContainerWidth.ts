import { useState, useEffect, useRef } from 'react';

export function useContainerWidth(options: { debounceMs?: number } = {}) {
  const [width, setWidth] = useState(1200);
  const [mounted, setMounted] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMounted(true);
    
    if (!containerRef.current) return;

    // Initial measurement
    const initialWidth = Math.floor(containerRef.current.getBoundingClientRect().width);
    if (initialWidth > 0) {
      setWidth(initialWidth);
    }

    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const newWidth = Math.floor(entry.contentRect.width);
        setWidth((prevWidth) => {
          // Require at least 20px difference to update, preventing scrollbar oscillation loops
          if (Math.abs(prevWidth - newWidth) > 20) {
            return newWidth;
          }
          return prevWidth;
        });
      }
    });

    observer.observe(containerRef.current);

    return () => {
      observer.disconnect();
    };
  }, []);

  return { width, containerRef, mounted, measureWidth: () => {} };
}
