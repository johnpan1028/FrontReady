import { Outlet, NavLink } from 'react-router-dom';
import { LayoutDashboard, Users, Briefcase, TrendingUp, Settings, PenTool } from 'lucide-react';
import { motion } from 'motion/react';
import { useAppStore } from '../store/appStore';
import { cn } from '../utils/cn';

export function MainLayout() {
  const { isSidebarOpen, setSidebarOpen } = useAppStore();

  const navItems = [
    { icon: LayoutDashboard, label: '驾驶舱 (Cockpit)', path: '/' },
    { icon: Briefcase, label: '组织 (Organization)', path: '/org' },
    { icon: Users, label: '人才 (Talent)', path: '/talent' },
    { icon: TrendingUp, label: '产能 (Productivity)', path: '/productivity' },
    { icon: PenTool, label: 'UI 构建器 (Visual Builder)', path: '/builder' },
  ];

  return (
    <div className="flex h-screen w-screen bg-hr-bg text-hr-text overflow-hidden font-sans">
      {/* Elastic Sidebar */}
      <motion.div 
        initial={false}
        animate={{ width: isSidebarOpen ? 240 : 64 }}
        className="h-full bg-hr-panel border-r border-hr-border flex flex-col relative z-20"
        onMouseEnter={() => setSidebarOpen(true)}
        onMouseLeave={() => setSidebarOpen(false)}
      >
        <div className="h-16 flex items-center justify-center border-b border-hr-border shrink-0">
          <div className="w-8 h-8 bg-hr-primary rounded flex items-center justify-center font-bold text-white shrink-0">
            HR
          </div>
          {isSidebarOpen && <span className="ml-3 font-bold tracking-wider text-sm whitespace-nowrap">HROS COCKPIT</span>}
        </div>
        
        <div className="flex-1 py-4 flex flex-col gap-2 overflow-hidden">
          {navItems.map((item, idx) => (
            <NavLink 
              key={idx}
              to={item.path}
              className={({ isActive }) => cn(
                "flex items-center px-5 py-3 transition-colors",
                isActive 
                  ? "text-hr-primary border-r-2 border-hr-primary bg-hr-primary/10" 
                  : "text-hr-muted hover:text-hr-text hover:bg-hr-border/50"
              )}
            >
              <item.icon size={20} className="shrink-0" />
              {isSidebarOpen && <span className="ml-4 text-sm whitespace-nowrap">{item.label}</span>}
            </NavLink>
          ))}
        </div>

        <div className="p-4 border-t border-hr-border shrink-0">
          <NavLink 
            to="/settings"
            className={({ isActive }) => cn(
              "flex items-center transition-colors w-full px-1 py-2 rounded-md",
              isActive ? "text-hr-primary" : "text-hr-muted hover:text-hr-text"
            )}
          >
            <Settings size={20} className="shrink-0" />
            {isSidebarOpen && <span className="ml-4 text-sm whitespace-nowrap">设置 (Settings)</span>}
          </NavLink>
        </div>
      </motion.div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Top Header */}
        <header className="h-16 bg-hr-bg border-b border-hr-border flex items-center justify-between px-6 shrink-0">
          <div>
            <h1 className="text-lg font-semibold text-hr-text">战略管控系统</h1>
            <p className="text-xs text-hr-muted">Strategic Control System • Live Data</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-xs text-hr-success bg-hr-success/10 px-2 py-1 rounded">
              <span className="w-2 h-2 rounded-full bg-hr-success animate-pulse"></span>
              System Online
            </div>
            <div className="w-8 h-8 rounded-full bg-hr-border flex items-center justify-center text-sm border border-hr-muted/30">
              CEO
            </div>
          </div>
        </header>

        {/* Page Content Area */}
        <main className="flex-1 overflow-hidden relative">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
