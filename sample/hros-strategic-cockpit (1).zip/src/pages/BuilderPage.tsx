import { useState, useEffect } from 'react';
import { ResponsiveGridLayout } from 'react-grid-layout';
import { useContainerWidth } from '../hooks/useContainerWidth';
import { useBuilderStore, WidgetType } from '../store/builderStore';
import { WidgetRegistry, setNestedCanvasComponent } from '../builder/registry';
import { NestedCanvas } from '../components/NestedCanvas';
import { Type, Heading, Square, BarChart2, MousePointerClick, Trash2, Settings2, LayoutPanelLeft, LayoutTemplate } from 'lucide-react';
import { cn } from '../utils/cn';

// Inject NestedCanvas to avoid circular dependencies
setNestedCanvasComponent(NestedCanvas);

const PALETTE_ITEMS: { type: WidgetType; label: string; icon: any; w: number; h: number }[] = [
  { type: 'panel', label: 'Panel (With Header)', icon: LayoutPanelLeft, w: 12, h: 8 },
  { type: 'canvas', label: 'Nested Canvas', icon: LayoutTemplate, w: 12, h: 6 },
  { type: 'heading', label: 'Heading', icon: Heading, w: 4, h: 2 },
  { type: 'text', label: 'Paragraph', icon: Type, w: 4, h: 3 },
  { type: 'button', label: 'Button', icon: MousePointerClick, w: 2, h: 2 },
  { type: 'stat', label: 'Stat Card', icon: Square, w: 3, h: 4 },
  { type: 'chart', label: 'Chart Block', icon: BarChart2, w: 6, h: 8 },
];

export function BuilderPage() {
  const { width, containerRef, mounted } = useContainerWidth();
  const { widgets, layouts, selectedId, draggedType, setDraggedType, addWidget, updateLayout, updateLayoutItem, updateWidgetProps, selectWidget, removeWidget } = useBuilderStore();

  const handleDrop = (layout: any[], item: any, e: any) => {
    const type = (e.dataTransfer?.getData('text/plain') || draggedType) as WidgetType;
    if (!type || !item) return;
    
    // Stop propagation so nested layouts don't trigger parent drops
    e.stopPropagation();
    
    const id = `widget_${Date.now()}`;
    const paletteItem = PALETTE_ITEMS.find(p => p.type === type);
    
    addWidget(id, type, {
      i: id,
      x: item.x,
      y: item.y,
      w: paletteItem?.w || 4,
      h: paletteItem?.h || 4,
    }, 'root');
    setDraggedType(null);
  };

  const selectedWidget = selectedId ? widgets[selectedId] : null;
  const selectedLayoutItem = selectedWidget ? layouts[selectedWidget.parentId]?.find(l => l.i === selectedId) : null;

  const paletteItem = draggedType ? PALETTE_ITEMS.find(p => p.type === draggedType) : null;

  const handleDropDragOver = (e: any) => {
    return { w: paletteItem?.w || 4, h: paletteItem?.h || 4 };
  };

  const rootLayout = layouts['root'] || [];

  return (
    <div className="flex h-full w-full bg-hr-bg overflow-hidden">
      {/* Left Palette */}
      <div className="w-64 bg-hr-panel border-r border-hr-border flex flex-col shrink-0 z-10">
        <div className="p-4 border-b border-hr-border">
          <h2 className="font-semibold text-hr-text flex items-center gap-2">
            <Settings2 size={18} />
            UI Components
          </h2>
          <p className="text-xs text-hr-muted mt-1">Drag and drop to canvas</p>
        </div>
        <div className="p-4 flex flex-col gap-3 overflow-y-auto">
          {PALETTE_ITEMS.map((item) => (
            <div
              key={item.type}
              className="droppableElement flex items-center gap-3 p-3 bg-hr-bg border border-hr-border rounded-lg cursor-grab hover:border-hr-primary hover:text-hr-primary transition-colors"
              draggable={true}
              unselectable="on"
              onDragStart={(e) => {
                e.dataTransfer.setData('text/plain', item.type);
                setDraggedType(item.type);
              }}
            >
              <item.icon size={18} />
              <span className="text-sm font-medium">{item.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Center Canvas */}
      <div 
        className="flex-1 overflow-y-scroll relative bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMiIgY3k9IjIiIHI9IjEiIGZpbGw9IiNFMkRDRDAiLz48L3N2Zz4=')] bg-repeat"
        onClick={() => selectWidget(null)}
        onDragOver={(e) => e.preventDefault()}
      >
        <div ref={containerRef} className="min-h-full p-8">
          {mounted && (
            <ResponsiveGridLayout
              className="layout min-h-[800px]"
              style={{ minHeight: '800px' }}
              layouts={{ lg: rootLayout }}
              width={width - 64} // Adjust for padding
              breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
              cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
              rowHeight={30}
              onDrop={handleDrop as any}
              dropConfig={{
                enabled: true,
                defaultItem: { w: paletteItem?.w || 4, h: paletteItem?.h || 4 },
                onDragOver: handleDropDragOver as any
              }}
              onLayoutChange={(currentLayout, allLayouts) => updateLayout('root', allLayouts.lg || currentLayout as any[])}
              margin={[16, 16]}
            >
              {rootLayout.map((item) => {
                const widget = widgets[item.i];
                if (!widget) return <div key={item.i} />;
                const Component = WidgetRegistry[widget.type];
                if (!Component) return <div key={item.i} />;
                const isSelected = selectedId === item.i;

                const widgetStyle: React.CSSProperties = {};
                if (widget.props.minWidth) widgetStyle.minWidth = `${widget.props.minWidth}px`;
                if (widget.props.minHeight) widgetStyle.minHeight = `${widget.props.minHeight}px`;
                if (widget.props.scaleWithParent === false) {
                  if (widget.props.minWidth) widgetStyle.width = `${widget.props.minWidth}px`;
                  if (widget.props.minHeight) widgetStyle.height = `${widget.props.minHeight}px`;
                }

                return (
                  <div 
                    key={item.i} 
                    data-grid={{
                      x: item.x,
                      y: item.y,
                      w: item.w,
                      h: item.h,
                      minW: widget.props.minW || 2,
                      minH: widget.props.minH || 2,
                    }}
                    className={cn(
                      "relative group rounded-lg transition-shadow overflow-hidden",
                      isSelected ? "ring-2 ring-hr-primary shadow-md" : "hover:ring-1 hover:ring-hr-border"
                    )}
                    onClick={(e) => {
                      e.stopPropagation();
                      selectWidget(item.i);
                    }}
                  >
                    <div className="w-full h-full" style={widgetStyle}>
                      <Component id={widget.id} {...widget.props} />
                    </div>
                    
                    {/* Delete Button (visible on hover or selected) */}
                    {(isSelected || true) && (
                      <button
                        className={cn(
                          "absolute -top-3 -right-3 bg-red-500 text-white p-1.5 rounded-full shadow-sm opacity-0 group-hover:opacity-100 transition-opacity z-10 hover:bg-red-600",
                          isSelected && "opacity-100"
                        )}
                        onClick={(e) => {
                          e.stopPropagation();
                          removeWidget(item.i);
                        }}
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                );
              })}
            </ResponsiveGridLayout>
          )}
          
          {rootLayout.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="text-center text-hr-muted bg-hr-panel/80 backdrop-blur-sm p-8 rounded-2xl border border-hr-border shadow-sm">
                <MousePointerClick size={48} className="mx-auto mb-4 opacity-50" />
                <h3 className="text-lg font-medium text-hr-text mb-1">Canvas is empty</h3>
                <p className="text-sm">Drag components from the left panel to start building.</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Right Properties Panel */}
      <div className="w-72 bg-hr-panel border-l border-hr-border flex flex-col shrink-0 z-10">
        <div className="p-4 border-b border-hr-border">
          <h2 className="font-semibold text-hr-text">Properties</h2>
          <p className="text-xs text-hr-muted mt-1">Configure selected element</p>
        </div>
        
        <div className="p-4 overflow-y-auto">
          {!selectedWidget ? (
            <div className="text-sm text-hr-muted text-center py-8">
              Select an element on the canvas to edit its properties.
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              <div className="text-xs font-mono text-hr-muted bg-hr-bg p-2 rounded border border-hr-border">
                ID: {selectedWidget.id}
                <br/>
                Type: {selectedWidget.type}
              </div>

              {selectedLayoutItem && (
                <div className="flex flex-col gap-3 pb-4 border-b border-hr-border">
                  <h3 className="text-xs font-semibold text-hr-text uppercase tracking-wider">Grid Layout (Cols/Rows)</h3>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-medium text-hr-text">Width</label>
                      <input 
                        type="number" 
                        min="1"
                        max="12"
                        className="w-full px-3 py-2 bg-hr-bg border border-hr-border rounded-md text-sm focus:outline-none focus:border-hr-primary focus:ring-1 focus:ring-hr-primary"
                        value={selectedLayoutItem.w || 1}
                        onChange={(e) => updateLayoutItem(selectedId!, selectedWidget.parentId, { w: parseInt(e.target.value) || 1 })}
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-medium text-hr-text">Height</label>
                      <input 
                        type="number" 
                        min="1"
                        className="w-full px-3 py-2 bg-hr-bg border border-hr-border rounded-md text-sm focus:outline-none focus:border-hr-primary focus:ring-1 focus:ring-hr-primary"
                        value={selectedLayoutItem.h || 1}
                        onChange={(e) => updateLayoutItem(selectedId!, selectedWidget.parentId, { h: parseInt(e.target.value) || 1 })}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-medium text-hr-text">Min Width (cols)</label>
                      <input 
                        type="number" 
                        min="1"
                        max="12"
                        className="w-full px-3 py-2 bg-hr-bg border border-hr-border rounded-md text-sm focus:outline-none focus:border-hr-primary focus:ring-1 focus:ring-hr-primary"
                        value={selectedLayoutItem.minW || 1}
                        onChange={(e) => updateLayoutItem(selectedId!, selectedWidget.parentId, { minW: parseInt(e.target.value) || 1 })}
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-medium text-hr-text">Min Height (rows)</label>
                      <input 
                        type="number" 
                        min="1"
                        className="w-full px-3 py-2 bg-hr-bg border border-hr-border rounded-md text-sm focus:outline-none focus:border-hr-primary focus:ring-1 focus:ring-hr-primary"
                        value={selectedLayoutItem.minH || 1}
                        onChange={(e) => updateLayoutItem(selectedId!, selectedWidget.parentId, { minH: parseInt(e.target.value) || 1 })}
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="flex flex-col gap-3 pb-4 border-b border-hr-border">
                <h3 className="text-xs font-semibold text-hr-text uppercase tracking-wider">Pixel Constraints</h3>
                
                <div className="flex items-center gap-2">
                  <input 
                    type="checkbox" 
                    id="scaleWithParent"
                    className="rounded border-hr-border text-hr-primary focus:ring-hr-primary"
                    checked={selectedWidget.props.scaleWithParent !== false}
                    onChange={(e) => updateWidgetProps(selectedId!, { scaleWithParent: e.target.checked })}
                  />
                  <label htmlFor="scaleWithParent" className="text-sm text-hr-text cursor-pointer">Scale with parent</label>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-medium text-hr-text">Min Width (px)</label>
                    <input 
                      type="number" 
                      min="0"
                      placeholder="e.g. 200"
                      className="w-full px-3 py-2 bg-hr-bg border border-hr-border rounded-md text-sm focus:outline-none focus:border-hr-primary focus:ring-1 focus:ring-hr-primary"
                      value={selectedWidget.props.minWidth || ''}
                      onChange={(e) => updateWidgetProps(selectedId!, { minWidth: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-medium text-hr-text">Min Height (px)</label>
                    <input 
                      type="number" 
                      min="0"
                      placeholder="e.g. 100"
                      className="w-full px-3 py-2 bg-hr-bg border border-hr-border rounded-md text-sm focus:outline-none focus:border-hr-primary focus:ring-1 focus:ring-hr-primary"
                      value={selectedWidget.props.minHeight || ''}
                      onChange={(e) => updateWidgetProps(selectedId!, { minHeight: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                </div>
              </div>

              {/* Dynamic Property Editors based on type */}
              {selectedWidget.type === 'panel' && (
                <>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-medium text-hr-text">Panel Title</label>
                    <input 
                      type="text" 
                      className="w-full px-3 py-2 bg-hr-bg border border-hr-border rounded-md text-sm focus:outline-none focus:border-hr-primary focus:ring-1 focus:ring-hr-primary"
                      value={selectedWidget.props.title || ''}
                      onChange={(e) => updateWidgetProps(selectedId!, { title: e.target.value })}
                    />
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <input 
                      type="checkbox" 
                      id="showHeader"
                      className="rounded border-hr-border text-hr-primary focus:ring-hr-primary"
                      checked={selectedWidget.props.showHeader !== false}
                      onChange={(e) => updateWidgetProps(selectedId!, { showHeader: e.target.checked })}
                    />
                    <label htmlFor="showHeader" className="text-sm text-hr-text cursor-pointer">Show Header Bar</label>
                  </div>
                </>
              )}

              {selectedWidget.type === 'heading' && (
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-medium text-hr-text">Heading Text</label>
                  <input 
                    type="text" 
                    className="w-full px-3 py-2 bg-hr-bg border border-hr-border rounded-md text-sm focus:outline-none focus:border-hr-primary focus:ring-1 focus:ring-hr-primary"
                    value={selectedWidget.props.text || ''}
                    onChange={(e) => updateWidgetProps(selectedId!, { text: e.target.value })}
                  />
                </div>
              )}

              {selectedWidget.type === 'text' && (
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-medium text-hr-text">Paragraph Content</label>
                  <textarea 
                    className="w-full px-3 py-2 bg-hr-bg border border-hr-border rounded-md text-sm focus:outline-none focus:border-hr-primary focus:ring-1 focus:ring-hr-primary min-h-[100px]"
                    value={selectedWidget.props.text || ''}
                    onChange={(e) => updateWidgetProps(selectedId!, { text: e.target.value })}
                  />
                </div>
              )}

              {selectedWidget.type === 'button' && (
                <>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-medium text-hr-text">Button Label</label>
                    <input 
                      type="text" 
                      className="w-full px-3 py-2 bg-hr-bg border border-hr-border rounded-md text-sm focus:outline-none focus:border-hr-primary focus:ring-1 focus:ring-hr-primary"
                      value={selectedWidget.props.text || ''}
                      onChange={(e) => updateWidgetProps(selectedId!, { text: e.target.value })}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-medium text-hr-text">Variant</label>
                    <select 
                      className="w-full px-3 py-2 bg-hr-bg border border-hr-border rounded-md text-sm focus:outline-none focus:border-hr-primary focus:ring-1 focus:ring-hr-primary"
                      value={selectedWidget.props.variant || 'primary'}
                      onChange={(e) => updateWidgetProps(selectedId!, { variant: e.target.value })}
                    >
                      <option value="primary">Primary</option>
                      <option value="secondary">Secondary</option>
                      <option value="outline">Outline</option>
                      <option value="ghost">Ghost</option>
                    </select>
                  </div>
                </>
              )}

              {selectedWidget.type === 'stat' && (
                <>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-medium text-hr-text">Title</label>
                    <input 
                      type="text" 
                      className="w-full px-3 py-2 bg-hr-bg border border-hr-border rounded-md text-sm focus:outline-none focus:border-hr-primary focus:ring-1 focus:ring-hr-primary"
                      value={selectedWidget.props.title || ''}
                      onChange={(e) => updateWidgetProps(selectedId!, { title: e.target.value })}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-medium text-hr-text">Value</label>
                    <input 
                      type="text" 
                      className="w-full px-3 py-2 bg-hr-bg border border-hr-border rounded-md text-sm focus:outline-none focus:border-hr-primary focus:ring-1 focus:ring-hr-primary"
                      value={selectedWidget.props.value || ''}
                      onChange={(e) => updateWidgetProps(selectedId!, { value: e.target.value })}
                    />
                  </div>
                </>
              )}
              
              {selectedWidget.type === 'chart' && (
                <div className="text-sm text-hr-muted">
                  Chart configuration options would go here (e.g., data source, chart type, colors).
                </div>
              )}

              <div className="pt-4 mt-4 border-t border-hr-border">
                <button
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-red-500/10 text-red-500 hover:bg-red-500/20 hover:text-red-600 rounded-md text-sm font-medium transition-colors"
                  onClick={() => removeWidget(selectedId!)}
                >
                  <Trash2 size={16} />
                  Delete Component
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
