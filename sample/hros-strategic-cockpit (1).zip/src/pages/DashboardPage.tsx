import { Dashboard } from '../Dashboard';

export function DashboardPage() {
  return (
    <div className="h-full w-full">
      <Dashboard />
    </div>
  );
}
