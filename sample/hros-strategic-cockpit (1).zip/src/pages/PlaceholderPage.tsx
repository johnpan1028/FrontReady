import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { useNavigate } from 'react-router-dom';

export function PlaceholderPage({ title }: { title: string }) {
  const navigate = useNavigate();
  
  return (
    <div className="p-8 h-full w-full flex flex-col gap-6 overflow-y-auto">
      <h1 className="text-2xl font-bold text-hr-text">{title}</h1>
      <Card className="p-6 flex-1 flex flex-col items-center justify-center text-hr-muted">
        <p className="mb-4">This module is currently under construction.</p>
        <Button variant="outline" onClick={() => navigate('/')}>Go Back to Dashboard</Button>
      </Card>
    </div>
  );
}
