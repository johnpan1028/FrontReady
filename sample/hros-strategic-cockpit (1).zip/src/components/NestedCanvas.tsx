import React, { useState } from 'react';
import { ResponsiveGridLayout } from 'react-grid-layout';
import { useContainerWidth } from '../hooks/useContainerWidth';
import { useBuilderStore, WidgetType } from '../store/builderStore';
import { WidgetRegistry } from '../builder/registry';
import { cn } from '../utils/cn';
import { MousePointerClick, Trash2 } from 'lucide-react';

interface NestedCanvasProps {
  id: string;
  className?: string;
}

export const NestedCanvas: React.FC<NestedCanvasProps> = ({ id, className }) => {
  const { widgets, layouts, selectedId, draggedType, setDraggedType, addWidget, updateLayout, selectWidget, removeWidget } = useBuilderStore();
  const { width, containerRef, mounted } = useContainerWidth();

  const layout = layouts[id] || [];

  const handleDrop = (layout: any[], item: any, e: any) => {
    if (e && typeof e.stopPropagation === 'function') {
      e.stopPropagation(); // Prevent parent canvas from handling this drop
    }
    const type = (e.dataTransfer?.getData('text/plain') || draggedType) as WidgetType;
    if (!type || !item) return;
    
    const newId = `widget_${Date.now()}`;
    
    // Default sizes for nested items
    const { w, h } = getPlaceholderSize(type);
    
    addWidget(newId, type, {
      i: newId,
      x: item.x,
      y: item.y,
      w,
      h,
    }, id);
    setDraggedType(null);
  };

  const getPlaceholderSize = (type: WidgetType | null) => {
    let w = 4;
    let h = 4;
    if (type === 'heading') { w = 4; h = 2; }
    if (type === 'text') { w = 4; h = 3; }
    if (type === 'button') { w = 2; h = 2; }
    if (type === 'stat') { w = 3; h = 4; }
    if (type === 'chart') { w = 6; h = 8; }
    if (type === 'panel') { w = 12; h = 8; }
    if (type === 'canvas') { w = 12; h = 6; }
    return { w, h };
  };

  const handleDropDragOver = (e: any) => {
    if (e && typeof e.stopPropagation === 'function') {
      e.stopPropagation();
    }
    return getPlaceholderSize(draggedType);
  };

  return (
    <div 
      className={cn("w-full h-full relative group/canvas", className)}
      onDragOver={(e) => e.stopPropagation()}
      onMouseDown={(e) => e.stopPropagation()}
      ref={containerRef}
    >
      {mounted && (
        <ResponsiveGridLayout
          className="layout min-h-[100px] h-full w-full"
          layouts={{ lg: layout }}
          width={width}
          breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
          cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
          rowHeight={30}
          onDrop={handleDrop as any}
          dropConfig={{
            enabled: true,
            defaultItem: getPlaceholderSize(draggedType),
            onDragOver: handleDropDragOver as any
          }}
          onLayoutChange={(currentLayout, allLayouts) => updateLayout(id, allLayouts.lg || currentLayout as any[])}
          margin={[8, 8]}
          dragConfig={{ enabled: true }}
          resizeConfig={{ enabled: true }}
        >
          {layout.map((item) => {
            const widget = widgets[item.i];
            if (!widget) return <div key={item.i} />;
            
            // Avoid circular dependencies by lazy loading or direct registry access
            const Component = WidgetRegistry[widget.type];
            if (!Component) return <div key={item.i} />;
            
            const isSelected = selectedId === item.i;

            const widgetStyle: React.CSSProperties = {};
            if (widget.props.minWidth) widgetStyle.minWidth = `${widget.props.minWidth}px`;
            if (widget.props.minHeight) widgetStyle.minHeight = `${widget.props.minHeight}px`;
            if (widget.props.scaleWithParent === false) {
              if (widget.props.minWidth) widgetStyle.width = `${widget.props.minWidth}px`;
              if (widget.props.minHeight) widgetStyle.height = `${widget.props.minHeight}px`;
            }

            return (
              <div 
                key={item.i} 
                data-grid={{
                  x: item.x,
                  y: item.y,
                  w: item.w,
                  h: item.h,
                  minW: widget.props.minW || 2,
                  minH: widget.props.minH || 2,
                }}
                className={cn(
                  "relative group rounded-lg transition-shadow overflow-hidden",
                  isSelected ? "ring-2 ring-hr-primary shadow-md" : "hover:ring-1 hover:ring-hr-border"
                )}
                onClick={(e) => {
                  e.stopPropagation();
                  selectWidget(item.i);
                }}
              >
                <div className="w-full h-full" style={widgetStyle}>
                  <Component id={widget.id} {...widget.props} />
                </div>
                
                {(isSelected || true) && (
                  <button
                    className={cn(
                      "absolute -top-3 -right-3 p-1.5 bg-red-500 text-white rounded-full shadow-sm z-50 transition-opacity",
                      isSelected ? "opacity-100" : "opacity-0 group-hover:opacity-100"
                    )}
                    onClick={(e) => {
                      e.stopPropagation();
                      removeWidget(item.i);
                    }}
                  >
                    <Trash2 size={14} />
                  </button>
                )}
              </div>
            );
          })}
        </ResponsiveGridLayout>
      )}
      
      {layout.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-0 group-hover/canvas:opacity-100 transition-opacity">
          <div className="text-center text-hr-muted bg-hr-panel/50 backdrop-blur-sm p-4 rounded-xl border border-hr-border border-dashed">
            <p className="text-xs">Drop widgets here</p>
          </div>
        </div>
      )}
    </div>
  );
};
