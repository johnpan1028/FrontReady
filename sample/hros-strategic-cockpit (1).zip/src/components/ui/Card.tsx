import { HTMLAttributes, forwardRef } from 'react';
import { cn } from '../../utils/cn';

export interface CardProps extends HTMLAttributes<HTMLDivElement> {}

export const Card = forwardRef<HTMLDivElement, CardProps>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          "bg-hr-panel border border-hr-border rounded-xl shadow-sm overflow-hidden",
          className
        )}
        {...props}
      />
    );
  }
);
Card.displayName = "Card";
