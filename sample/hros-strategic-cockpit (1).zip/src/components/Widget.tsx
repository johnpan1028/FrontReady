import { ReactNode } from 'react';
import { Settings, Maximize2 } from 'lucide-react';

interface WidgetProps {
  title: string;
  children: ReactNode;
  onSettings?: () => void;
}

export function Widget({ title, children, onSettings }: WidgetProps) {
  return (
    <div className="flex flex-col h-full w-full">
      <div className="flex items-center justify-between px-4 py-3 border-b border-hr-border cursor-move drag-handle bg-hr-panel">
        <h3 className="text-xs font-semibold text-hr-text uppercase tracking-wider">{title}</h3>
        <div className="flex items-center gap-2 opacity-0 hover:opacity-100 transition-opacity">
          {onSettings && (
            <button onClick={onSettings} className="text-hr-muted hover:text-hr-text transition-colors">
              <Settings size={14} />
            </button>
          )}
          <button className="text-hr-muted hover:text-hr-text transition-colors">
            <Maximize2 size={14} />
          </button>
        </div>
      </div>
      <div className="flex-1 overflow-hidden p-3 relative">
        {children}
      </div>
    </div>
  );
}
