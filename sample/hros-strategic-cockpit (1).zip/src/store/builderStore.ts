import { create } from 'zustand';

export type WidgetType = 'heading' | 'text' | 'button' | 'stat' | 'chart' | 'panel' | 'canvas';

export interface WidgetData {
  id: string;
  type: WidgetType;
  props: Record<string, any>;
  parentId: string;
}

interface BuilderStore {
  widgets: Record<string, WidgetData>;
  layouts: Record<string, any[]>;
  selectedId: string | null;
  draggedType: WidgetType | null;
  setDraggedType: (type: WidgetType | null) => void;
  addWidget: (id: string, type: WidgetType, layoutItem: any, parentId?: string) => void;
  updateLayout: (parentId: string, layout: any[]) => void;
  updateLayoutItem: (id: string, parentId: string, updates: Partial<any>) => void;
  updateWidgetProps: (id: string, props: Record<string, any>) => void;
  selectWidget: (id: string | null) => void;
  removeWidget: (id: string) => void;
}

const defaultProps: Record<WidgetType, Record<string, any>> = {
  heading: { text: 'New Heading' },
  text: { text: 'Enter your text here...' },
  button: { text: 'Click Me', variant: 'primary' },
  stat: { title: 'Total Users', value: '1,024' },
  chart: {},
  panel: { title: 'New Panel', showHeader: true, collapsed: false },
  canvas: {},
};

export const useBuilderStore = create<BuilderStore>((set) => ({
  widgets: {},
  layouts: { root: [] },
  selectedId: null,
  draggedType: null,
  
  setDraggedType: (type) => set({ draggedType: type }),
  
  addWidget: (id, type, layoutItem, parentId = 'root') => set((state) => {
    const newLayouts = { ...state.layouts };
    if (!newLayouts[parentId]) newLayouts[parentId] = [];
    newLayouts[parentId] = [...newLayouts[parentId], layoutItem];
    
    return {
      widgets: {
        ...state.widgets,
        [id]: { id, type, parentId, props: { ...defaultProps[type] } }
      },
      layouts: newLayouts,
      selectedId: id,
    };
  }),
  
  updateLayout: (parentId, layout) => set((state) => {
    const currentLayout = state.layouts[parentId] || [];
    const layoutIds = new Set(layout.map(l => l.i));
    const missing = currentLayout.filter(l => !layoutIds.has(l.i) && state.widgets[l.i]);
    
    const newLayout = [...layout, ...missing];
    
    // Robust equality check to prevent infinite loops from react-grid-layout
    const sortedCurrent = [...currentLayout].sort((a, b) => a.i.localeCompare(b.i));
    const sortedNew = [...newLayout].sort((a, b) => a.i.localeCompare(b.i));
    
    const isEqual = sortedCurrent.length === sortedNew.length && sortedCurrent.every((item, index) => {
      const newItem = sortedNew[index];
      if (!newItem) return false;
      return item.i === newItem.i && 
             item.x === newItem.x && 
             item.y === newItem.y && 
             item.w === newItem.w && 
             item.h === newItem.h &&
             (item.minW || undefined) === (newItem.minW || undefined) &&
             (item.minH || undefined) === (newItem.minH || undefined);
    });

    if (isEqual) {
      return state;
    }
    
    console.log(`[updateLayout] Layout changed for ${parentId}`, { current: sortedCurrent, new: sortedNew });
    
    return { 
      layouts: {
        ...state.layouts,
        [parentId]: newLayout
      }
    };
  }),
  
  updateLayoutItem: (id, parentId, updates) => set((state) => {
    const currentLayout = state.layouts[parentId] || [];
    const newLayout = currentLayout.map(item => 
      item.i === id ? { ...item, ...updates } : item
    );
    return {
      layouts: {
        ...state.layouts,
        [parentId]: newLayout
      }
    };
  }),
  
  updateWidgetProps: (id, props) => set((state) => ({
    widgets: {
      ...state.widgets,
      [id]: { ...state.widgets[id], props: { ...state.widgets[id].props, ...props } }
    }
  })),
  
  selectWidget: (id) => set({ selectedId: id }),
  
  removeWidget: (id) => set((state) => {
    const widget = state.widgets[id];
    if (!widget) return state;
    
    const newWidgets = { ...state.widgets };
    delete newWidgets[id];
    
    const newLayouts = { ...state.layouts };
    if (newLayouts[widget.parentId]) {
      newLayouts[widget.parentId] = newLayouts[widget.parentId].filter(item => item.i !== id);
    }
    
    // Also remove any children if it's a container
    if (widget.type === 'panel' || widget.type === 'canvas') {
      const children = Object.values(newWidgets).filter(w => w.parentId === id);
      children.forEach(child => {
        delete newWidgets[child.id];
      });
      delete newLayouts[id];
    }
    
    return {
      widgets: newWidgets,
      layouts: newLayouts,
      selectedId: state.selectedId === id ? null : state.selectedId
    };
  }),
}));
